﻿using UnityEngine;

public class PhysicsPointer : Pointer
{

}
